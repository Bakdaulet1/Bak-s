<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="form-wrapper"> 
    <center><h3> </h3></center>
<?php


	echo "Someone already registered using this email. <br>";
    echo "\n\n Click "; 
	echo '<a href="ResponsiveRegistration.php">here</a>';
	echo  " to register again using a different email.";
	
	
?>
</div>

</body>
</html>
