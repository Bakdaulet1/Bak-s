<?php
$con = mysqli_connect("localhost","baitan1","S216242","CommunityScholarship");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>
